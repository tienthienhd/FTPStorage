/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ftpstorage.views;

/**
 *
 * @author HP Zbook 15
 */
public interface FileStatusListener {

    public void notifySelected(FileStatus file);
}
